This code was ran and compiled on the csx2 server
it was compiled using gcc assignment2_hill_Connor.c -lrt
ran with ./a.out