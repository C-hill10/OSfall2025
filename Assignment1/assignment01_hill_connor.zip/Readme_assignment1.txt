Csx server: CSX 1
All programs were compiled with gcc (file) and then ran with ./a.out